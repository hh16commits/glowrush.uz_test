import { io } from "/socket.io/socket.io.min.js";
import { LANGUAGES } from "./lang.js";

let currentLang = localStorage.getItem('glowrush_lang') || 'RU';

// Elements
const popularSlider = document.getElementById('popularSlider');
const productGrid = document.getElementById('productGrid');
const promotionsList = document.getElementById('promotionsList');
const cartBtn = document.getElementById('cartBtn');
const cartPanel = document.getElementById('cartPanel');
const cartItemsEl = document.getElementById('cartItems');
const closeCart = document.getElementById('closeCart');
const cartCount = document.getElementById('cartCount');
const cartTotalEl = document.getElementById('cartTotal');
const filterToggle = document.getElementById('filterToggle');
const filtersEl = document.getElementById('filters');
const categoryList = document.getElementById('categoryList');
const priceRange = document.getElementById('priceRange');
const priceMax = document.getElementById('priceMax');
const sortSelect = document.getElementById('sortSelect');
const checkoutBtn = document.getElementById('checkoutBtn');

// Языковой переключатель
function setLanguage(lang) {
  currentLang = lang;
  localStorage.setItem('glowrush_lang', lang);
  updateTexts();
  updateActiveLang();
}
function updateActiveLang() {
  document.querySelectorAll('.lang-switcher .lang').forEach(btn => {
    btn.classList.toggle('active', btn.textContent === currentLang);
  });
}
document.querySelectorAll('.lang-switcher .lang').forEach(btn => {
  btn.addEventListener('click', () => setLanguage(btn.textContent));
});

// Обновляет надписи на текущий язык
function updateTexts() {
  // Навигация
  document.querySelector('.nav-link[href="#catalog"]').textContent = LANGUAGES[currentLang].catalog;
  document.querySelector('.nav-link[href="#promotions"]').textContent = LANGUAGES[currentLang].promotions;
  document.querySelector('.nav-link[href="#contacts"]').textContent = LANGUAGES[currentLang].contacts;
  // Популярные
  document.querySelector('#popular .section-title').textContent = LANGUAGES[currentLang].popularProducts;
  // Каталог, фильтры
  document.querySelector('#catalog .section-title').textContent = LANGUAGES[currentLang].catalog;
  filterToggle.textContent = LANGUAGES[currentLang].filters;
  sortSelect.options[0].textContent = LANGUAGES[currentLang].sortPopular;
  sortSelect.options[1].textContent = LANGUAGES[currentLang].sortPriceAsc;
  sortSelect.options[2].textContent = LANGUAGES[currentLang].sortPriceDesc;
  sortSelect.options[3].textContent = LANGUAGES[currentLang].sortNew;
  // Акции
  document.querySelector('#promotions .section-title').textContent = LANGUAGES[currentLang].promotionsTitle;
  // Корзина и оформление
  checkoutBtn.textContent = LANGUAGES[currentLang].checkout;
  document.querySelector('.cart-head h4').textContent = LANGUAGES[currentLang].cart;
  document.querySelector('.cart-footer .cart-totals').childNodes[0].nodeValue = LANGUAGES[currentLang].total + ': $';
  // Контакты
  document.querySelector('#contacts .section-title').textContent = LANGUAGES[currentLang].contactsTitle;
  // Форма обратной связи (можно добавить)
}

let products = [];
let promotions = [];
let cart = JSON.parse(localStorage.getItem('glowrush_cart') || '[]');

// ----- Код магазина как был (State, fetchData, рендеры, корзина, checkout, ...)

document.getElementById('checkoutBtn').addEventListener('click', openCheckout);

async function fetchData() {
  const [pRes, promoRes] = await Promise.all([
    fetch('/api/products').then(r=>r.json()),
    fetch('/api/promotions').then(r=>r.json())
  ]);
  products = pRes.products || [];
  promotions = promoRes.promotions || [];
  renderAll();
}

function renderAll() {
  renderPopular();
  renderCatalog();
  renderPromotions();
  renderCart();
  renderFilters();
  updateTexts();
}

function renderPopular() {
  popularSlider.innerHTML = '';
  const popular = products.filter(p => p.popular).slice(0,6);
  for (const p of popular) {
    const slide = document.createElement('div');
    slide.className = 'slide';
    slide.innerHTML = `
      <div class="img" style="background-image:url('${p.images?.[0] || ''}')"></div>
      <div class="meta">
        <h4>${p.name}</h4>
        <div class="p-price">${p.salePrice ? `<span style="text-decoration:line-through;color:#b7b7b7">$${p.price}</span> <strong style="color:${p.salePrice ? 'var(--deep-pink)' : 'var(--text)'}">$${p.salePrice || p.price}</strong>` : '$' + p.price}</div>
      </div>
    `;
    slide.addEventListener('mouseenter', () => slide.style.transform = 'translateY(-6px) scale(1.02)');
    slide.addEventListener('mouseleave', () => slide.style.transform = '');
    popularSlider.appendChild(slide);
  }
}

function renderCatalog() {
  productGrid.innerHTML = '';
  let list = [...products];

  // Filters
  const maxPrice = Number(priceRange.value || 9999);
  list = list.filter(p => (p.salePrice || p.price) <= maxPrice);

  // Sort
  const sort = sortSelect.value;
  if (sort === 'price_asc') list.sort((a,b) => (a.salePrice||a.price) - (b.salePrice||b.price));
  if (sort === 'price_desc') list.sort((a,b) => (b.salePrice||b.price) - (a.salePrice||a.price));
  if (sort === 'new') list.sort((a,b) => (b.id.localeCompare(a.id)));
  if (sort === 'popular') list.sort((a,b) => (b.popular - a.popular));

  const tpl = document.getElementById('productCardTpl');

  for (const p of list) {
    const node = tpl.content.cloneNode(true);
    const card = node.querySelector('.product-card');
    card.querySelector('.imgwrap').style.backgroundImage = `url('${p.images?.[0] || ''}')`;
    card.querySelector('.p-name').textContent = p.name;
    card.querySelector('.p-price').innerHTML = p.salePrice ? `<span class="muted" style="text-decoration:line-through;color:#b7b7b7">$${p.price}</span> <strong>$${p.salePrice}</strong>` : `$${p.price}`;
    card.querySelector('.btn-add').textContent = LANGUAGES[currentLang].addToCart;
    card.querySelector('.btn-add').addEventListener('click', () => addToCart(p.id));
    card.querySelector('.link-details').textContent = LANGUAGES[currentLang].details;
    card.querySelector('.link-details').addEventListener('click', (e) => { e.preventDefault(); openProductModal(p); });
    productGrid.appendChild(node);
  }
}

function renderPromotions() {
  promotionsList.innerHTML = '';
  for (const promo of promotions) {
    const div = document.createElement('div');
    div.className = 'promo-card';
    div.style.backgroundImage = `url('${promo.image}')`;
    div.innerHTML = `
      <div>
        <h3>${promo.title}</h3>
        <p>${promo.subtitle || ''}</p>
      </div>
      <a class="cta" href="${promo.target || '#'}">${promo.ctaText || LANGUAGES[currentLang].details}</a>
    `;
    promotionsList.appendChild(div);
  }
}

function renderFilters() {
  // categories
  const cats = Array.from(new Set(products.map(p => p.category).filter(Boolean)));
  categoryList.innerHTML = '';
  for (const c of cats) {
    const btn = document.createElement('button');
    btn.className = 'chip';
    btn.textContent = c;
    btn.addEventListener('click', () => {
      document.querySelectorAll('.chip').forEach(x=>x.classList.remove('active'));
      btn.classList.add('active');
      const filtered = products.filter(p => p.category === c);
      productGrid.innerHTML = '';
      for (const p of filtered) {
        const el = document.querySelector('#productCardTpl').content.cloneNode(true);
        const card = el.querySelector('.product-card');
        card.querySelector('.imgwrap').style.backgroundImage = `url('${p.images?.[0] || ''}')`;
        card.querySelector('.p-name').textContent = p.name;
        card.querySelector('.p-price').textContent = `$${p.salePrice || p.price}`;
        card.querySelector('.btn-add').textContent = LANGUAGES[currentLang].addToCart;
        el.querySelector('.btn-add').addEventListener('click', () => addToCart(p.id));
        productGrid.appendChild(el);
      }
    });
    categoryList.appendChild(btn);
  }
}

// --- Cart logic, остальное ---

function addToCart(productId) {
  const p = products.find(x => x.id === productId);
  if (!p) return;
  const existing = cart.find(i => i.id === productId);
  if (existing) existing.qty++;
  else cart.push({ id: productId, qty: 1, name: p.name, price: p.salePrice || p.price, img: p.images?.[0] || '' });
  persistCart();
  renderCart();
  cartBtn.animate([{ transform: 'scale(1.05)' }, { transform: 'scale(1)' }], { duration: 220 });
}

function persistCart() {
  localStorage.setItem('glowrush_cart', JSON.stringify(cart));
}

function renderCart() {
  cartItemsEl.innerHTML = '';
  let total = 0;
  for (const item of cart) {
    total += item.price * item.qty;
    const div = document.createElement('div');
    div.className = 'cart-item';
    div.innerHTML = `
      <img src="${item.img}" alt="${item.name}" />
      <div style="flex:1">
        <div style="font-weight:600">${item.name}</div>
        <div style="color:var(--muted)">$${item.price} × <input type="number" min="1" value="${item.qty}" style="width:56px" data-id="${item.id}" class="qtyInput"></div>
      </div>
      <div><button class="removeBtn" data-id="${item.id}">✕</button></div>
    `;
    cartItemsEl.appendChild(div);
  }
  cartItemsEl.querySelectorAll('.qtyInput').forEach(inp => {
    inp.addEventListener('change', (e) => {
      const id = e.target.dataset.id;
      const val = Math.max(1, Number(e.target.value || 1));
      const it = cart.find(i => i.id === id);
      if (it) it.qty = val;
      persistCart();
      renderCart();
    });
  });
  cartItemsEl.querySelectorAll('.removeBtn').forEach(btn => {
    btn.addEventListener('click', () => {
      const id = btn.dataset.id;
      cart = cart.filter(i => i.id !== id);
      persistCart();
      renderCart();
    });
  });

  cartCount.textContent = cart.reduce((s, i) => s + i.qty, 0);
  cartTotalEl.textContent = total.toFixed(2);
}

// UI interactions
cartBtn.addEventListener('click', () => {
  cartPanel.classList.toggle('hidden');
});
closeCart.addEventListener('click', () => cartPanel.classList.add('hidden'));

filterToggle.addEventListener('click', () => {
  filtersEl.classList.toggle('hidden');
});

priceRange.addEventListener('input', () => {
  priceMax.textContent = priceRange.value;
  renderCatalog();
});
sortSelect.addEventListener('change', () => renderCatalog());

// Contact form
document.getElementById('contactForm').addEventListener('submit', async (e) => {
  e.preventDefault();
  const fd = Object.fromEntries(new FormData(e.target).entries());
  await fetch('/api/feedback', { method: 'POST', headers:{'content-type':'application/json'}, body: JSON.stringify(fd) });
  alert('Спасибо! Сообщение отправлено.');
  e.target.reset();
});

// Checkout
async function openCheckout() {
  if (!cart.length) { alert('Корзина пуста'); return; }
  const name = prompt('Имя для заказа');
  if (!name) return;
  const phone = prompt('Телефон');
  if (!phone) return;
  const address = prompt('Адрес доставки');
  if (!address) return;
  const order = { customer: { name, phone, address }, items: cart, total: cart.reduce((s,i)=>s+i.price*i.qty,0) };
  const res = await fetch('/api/orders', { method: 'POST', headers:{'content-type':'application/json'}, body: JSON.stringify(order) });
  const data = await res.json();
  if (data.ok) {
    alert('Заказ принят! Спасибо ❤️');
    cart = [];
    persistCart();
    renderCart();
  } else {
    alert('Ошибка оформления заказа');
  }
}

function openProductModal(product) {
  const modal = document.createElement('div');
  modal.style.position='fixed';modal.style.inset=0;modal.style.background='rgba(0,0,0,0.5)';
  modal.style.display='flex';modal.style.alignItems='center';modal.style.justifyContent='center';modal.style.zIndex=2000;
  modal.innerHTML = `
    <div style="background:#fff;border-radius:12px;max-width:900px;width:92%;display:flex;gap:20px;padding:18px">
      <div style="flex:1">
        <div style="height:360px;background-image:url('${product.images?.[0]||''}');background-size:cover;border-radius:8px"></div>
        <div style="display:flex;gap:8px;margin-top:8px">
          ${product.images?.slice(0,4).map(url=>`<div style="width:64px;height:64px;background-image:url('${url}');background-size:cover;border-radius:8px"></div>`).join('')}
        </div>
      </div>
      <div style="width:360px">
        <h2 style="margin-top:0">${product.name}</h2>
        <p style="color:var(--muted)">${product.description || ''}</p>
        <div style="font-size:20px;margin:10px 0">${product.stock>5?'<span style="color:green">В наличии</span>':product.stock>0?'<span style="color:orange">Мало</span>':'<span style="color:red">Нет в наличии</span>'}</div>
        <div style="font-weight:700;font-size:18px;margin-bottom:12px">${product.salePrice?`<span style="text-decoration:line-through;color:#b7b7b7">$${product.price}</span> <strong>$${product.salePrice}</strong>`:`$${product.price}`}</div>
        <div style="display:flex;gap:8px">
          <button class="btn btn-primary" id="modalAdd">${LANGUAGES[currentLang].addToCart}</button>
          <button class="btn btn-secondary" id="modalBuy">${LANGUAGES[currentLang].checkout}</button>
        </div>
      </div>
    </div>
  `;
  document.body.appendChild(modal);
  modal.addEventListener('click', (e)=>{ if (e.target===modal) modal.remove(); });
  modal.querySelector('#modalAdd').addEventListener('click', ()=>{ addToCart(product.id); modal.remove(); });
  modal.querySelector('#modalBuy').addEventListener('click', async ()=>{ addToCart(product.id); await openCheckout(); modal.remove(); });
}

// Socket events
const socket = io();
socket.on('connect', () => console.log('socket connected'));
socket.on('productsUpdated', (data) => { products = data; renderAll(); });
socket.on('promotionsUpdated', (data) => { promotions = data; renderAll(); });
socket.on('ordersUpdated', (data) => { console.log('orders updated (admin):', data); });

// Init
fetchData();
updateTexts();
updateActiveLang();