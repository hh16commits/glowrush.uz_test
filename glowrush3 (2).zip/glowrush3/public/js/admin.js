import { io } from "/socket.io/socket.io.js";
const socket = io();

const productList = document.getElementById('productList');
const promoList = document.getElementById('promoList');
const ordersList = document.getElementById('ordersList');
const productForm = document.getElementById('productForm');
const promoForm = document.getElementById('promoForm');

let products = [];
let promotions = [];
let orders = [];

socket.on('productsUpdated', (data) => { products = data; renderProducts(); });
socket.on('promotionsUpdated', (data) => { promotions = data; renderPromos(); });
socket.on('ordersUpdated', (data) => { orders = data; renderOrders(); });

function renderProducts() {
  productList.innerHTML = '';
  for (const p of products) {
    const row = document.createElement('div');
    row.className = 'product-row';
    row.innerHTML = `<div class="meta"><strong>${p.name}</strong><div style="color:var(--muted)">$${p.salePrice || p.price} • ${p.category || '-'}</div></div>
      <div style="display:flex;gap:8px">
        <button class="btn btn-secondary edit" data-id="${p.id}">Edit</button>
      </div>`;
    productList.appendChild(row);
  }
  productList.querySelectorAll('.edit').forEach(btn => {
    btn.addEventListener('click', () => {
      const id = btn.dataset.id;
      const p = products.find(x => x.id === id);
      if (!p) return;
      productForm.id.value = p.id;
      productForm.name.value = p.name;
      productForm.price.value = p.price;
      productForm.salePrice.value = p.salePrice || 0;
      productForm.stock.value = p.stock || 0;
      productForm.category.value = p.category || '';
      productForm.images.value = (p.images||[]).join(',');
      productForm.description.value = p.description || '';
      window.scrollTo({top:0,behavior:'smooth'});
    });
  });
}

function renderPromos() {
  promoList.innerHTML = '';
  for (const p of promotions) {
    const row = document.createElement('div');
    row.className = 'product-row';
    row.innerHTML = `<div class="meta"><strong>${p.title}</strong><div style="color:var(--muted)">${p.subtitle || ''}</div></div>
      <div style="display:flex;gap:8px">
        <button class="btn btn-secondary editPromo" data-id="${p.id}">Edit</button>
      </div>`;
    promoList.appendChild(row);
  }
  promoList.querySelectorAll('.editPromo').forEach(btn => {
    btn.addEventListener('click', () => {
      const id = btn.dataset.id;
      const p = promotions.find(x => x.id === id);
      if (!p) return;
      promoForm.id.value = p.id;
      promoForm.title.value = p.title;
      promoForm.subtitle.value = p.subtitle;
      promoForm.image.value = p.image;
      promoForm.ctaText.value = p.ctaText;
      promoForm.target.value = p.target || '';
      window.scrollTo({top:0,behavior:'smooth'});
    });
  });
}

function renderOrders() {
  ordersList.innerHTML = '';
  for (const o of orders) {
    const div = document.createElement('div');
    div.style.padding='8px';
    div.style.borderBottom='1px solid rgba(0,0,0,0.04)';
    div.innerHTML = `<strong>${o.customer?.name || '—'}</strong> • $${o.total} • <div style="color:var(--muted);font-size:12px">${new Date(o.createdAt).toLocaleString()}</div>`;
    ordersList.appendChild(div);
  }
}

// Forms
productForm.addEventListener('submit', async (e) => {
  e.preventDefault();
  const fd = new FormData(productForm);
  const payload = {
    id: fd.get('id') || 'p' + Date.now(),
    name: fd.get('name'),
    price: Number(fd.get('price')),
    salePrice: Number(fd.get('salePrice')||0),
    stock: Number(fd.get('stock')||0),
    category: fd.get('category'),
    images: (fd.get('images') || '').split(',').map(s => s.trim()).filter(Boolean),
    description: fd.get('description'),
    popular: false
  };
  await fetch('/api/admin/products', { method: 'POST', headers:{'content-type':'application/json'}, body: JSON.stringify(payload) });
  productForm.reset();
});

promoForm.addEventListener('submit', async (e) => {
  e.preventDefault();
  const fd = new FormData(promoForm);
  const payload = {
    id: fd.get('id') || 'promo' + Date.now(),
    title: fd.get('title'),
    subtitle: fd.get('subtitle'),
    image: fd.get('image'),
    ctaText: fd.get('ctaText'),
    target: fd.get('target')
  };
  await fetch('/api/admin/promotions', { method: 'POST', headers:{'content-type':'application/json'}, body: JSON.stringify(payload) });
  promoForm.reset();
});

// initial load (server will emit current data)