const express = require('express');
const fs = require('fs');
const path = require('path');
const http = require('http');
const bodyParser = require('body-parser');
const cors = require('cors');
const { Server } = require('socket.io');

const DATA_FILE = path.join(__dirname, 'data.json');

function readData() {
  try {
    const raw = fs.readFileSync(DATA_FILE, 'utf8');
    return JSON.parse(raw);
  } catch (e) {
    return { products: [], promotions: [], orders: [] };
  }
}
function writeData(data) {
  fs.writeFileSync(DATA_FILE, JSON.stringify(data, null, 2), 'utf8');
}

const app = express();
const server = http.createServer(app);
const io = new Server(server);

app.use(cors());
app.use(bodyParser.json());
app.use(express.static(path.join(__dirname, 'public')));

// API: get products and promotions
app.get('/api/products', (req, res) => {
  const data = readData();
  res.json({ products: data.products });
});
app.get('/api/promotions', (req, res) => {
  const data = readData();
  res.json({ promotions: data.promotions });
});

// Admin endpoints (demo: no auth)
app.post('/api/admin/products', (req, res) => {
  const data = readData();
  const product = req.body;
  const idx = data.products.findIndex(p => p.id === product.id);
  if (idx >= 0) {
    data.products[idx] = product;
  } else {
    data.products.unshift(product);
  }
  writeData(data);
  io.emit('productsUpdated', data.products);
  res.json({ ok: true, products: data.products });
});

app.post('/api/admin/promotions', (req, res) => {
  const data = readData();
  const promo = req.body;
  const idx = data.promotions.findIndex(p => p.id === promo.id);
  if (idx >= 0) data.promotions[idx] = promo;
  else data.promotions.unshift(promo);
  writeData(data);
  io.emit('promotionsUpdated', data.promotions);
  res.json({ ok: true, promotions: data.promotions });
});

// Place an order
app.post('/api/orders', (req, res) => {
  const data = readData();
  const order = req.body;
  order.id = 'o' + Date.now();
  order.createdAt = new Date().toISOString();
  order.status = 'new';
  data.orders.unshift(order);
  writeData(data);
  io.emit('ordersUpdated', data.orders); // notify admin clients
  res.json({ ok: true, order });
});

// Simple feedback endpoint
app.post('/api/feedback', (req, res) => {
  console.log('Feedback:', req.body);
  res.json({ ok: true });
});

// Socket.IO connection
io.on('connection', (socket) => {
  console.log('Socket connected:', socket.id);
  // Send current data on connect
  const data = readData();
  socket.emit('productsUpdated', data.products);
  socket.emit('promotionsUpdated', data.promotions);
  socket.emit('ordersUpdated', data.orders);

  socket.on('ping', (d) => socket.emit('pong', d));
});

const PORT = process.env.PORT || 3000;
server.listen(PORT, () => {
  console.log(`GlowRush mock server running on http://localhost:${PORT}`);
});